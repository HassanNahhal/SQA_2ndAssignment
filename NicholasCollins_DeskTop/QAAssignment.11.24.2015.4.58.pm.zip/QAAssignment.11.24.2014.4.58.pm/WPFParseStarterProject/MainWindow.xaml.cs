﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Parse;
using System.Windows.Threading;



namespace WPFParseStarterProject {
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window {

    public string lastObjectId = "";
    public bool pastFirstTime = false;
    public const string queryItemName = "ChatMessages";
    public const string parseObjectName = "GPSFromServer";     

    Dictionary<bool, string> MessageTextHeaders = new Dictionary<bool, string>();
   // public string privateString = "[Private]";
    
      
    public  MainWindow() {
      InitializeComponent();
      MessageTextHeaders.Add(true, "[Private] ");
      MessageTextHeaders.Add(false, "");
      DispatcherTimer timer = new DispatcherTimer();
      timer.Interval = TimeSpan.FromSeconds(1);
      timer.Tick += timer_Tick;
      timer.Start();     
    }

    private async void InitialMethod()
    {

          
        ParseObject GPSParseObject2 = new ParseObject(parseObjectName);          
        var query = ParseObject.GetQuery(queryItemName).Limit(1000);
        IEnumerable<ParseObject> results = await query.FindAsync();           

        foreach (ParseObject messages in results)
        {
            try
            {
                string MessageBody = messages.Get<string>("MessageText");
                string From = messages.Get<string>("Id");
                string To = messages.Get<string>("To");               
                if (((messages.Get<Boolean>("Private") && To == txtBxMyId.Text) || (messages.Get<Boolean>("Private") == false) || (From == txtBxMyId.Text)) && MessageBody != "")
                {
                    displayMessagesForUser(messages, MessageBody, From);
                }
            }
            catch (Exception ex)
            {
                continue;
            }            
            lastObjectId = messages.ObjectId;
        }

        listMessages.SelectedIndex = listMessages.Items.Count - 1;
        listMessages.ScrollIntoView(listMessages.SelectedItem);
      
    }

    public void displayMessagesForUser(ParseObject messages, string MessageBody, string From)
    {
        string messageString = "";
        if (From == txtBxMyId.Text)
        {
            messageString += "Me";
        }
        else
        {
            messageString += From;
        }

        messageString += MessageTextHeaders[messages.Get<Boolean>("Private")];
        messageString += ": " + MessageBody;
        listMessages.Items.Add(messageString);       
    }

    async void timer_Tick(object sender, EventArgs e)
    //Check for new messages
    {
        var query = ParseObject.GetQuery(queryItemName).Limit(1000);
        IEnumerable<ParseObject> results = await query.FindAsync();

        
        string MessageBody = "";
        string From = "";
        string To = "";
        string objectId = "";
        bool privateFlag = false;

        foreach (ParseObject messages in results)
        {
            try
            {

                MessageBody = messages.Get<string>("MessageText");
                From = messages.Get<string>("Id");
                objectId = messages.ObjectId;
                privateFlag = (messages.Get<Boolean>("Private"));
                To = messages.Get<string>("To");
               
            }
            catch (Exception ex)
            {
                continue;
            }
            
        }

        //if a new messages is found, do additional checks to see if we want to display it and add it to the listBox when appropriate.

        if (objectId != lastObjectId)
        {
            checkAndDisplayMessages(privateFlag, MessageBody, To, From);
            lastObjectId = objectId;
        }
    }
    
    
    public void checkAndDisplayMessages(bool privateFlag, string MessageBody, string To, string From)
    {                  
        if (((privateFlag && To == txtBxMyId.Text) || (privateFlag == false) && To != ""  && MessageBody != "") && pastFirstTime)                
        {                  
            listMessages.Items.Add(From + MessageTextHeaders[privateFlag] +  ": " + MessageBody);
            listMessages.SelectedIndex = listMessages.Items.Count - 1;
            listMessages.ScrollIntoView(listMessages.SelectedItem);                
        }
        if (!pastFirstTime)
        {
            pastFirstTime = true;
        }        
    }

    public  async void sendMessage()
    {
        //Due to the asyncrhonous nature of using ParseObject methods, this logic has to be here inside the sendMessage method.  
        bool privateFlag = chckBxPrivate.IsChecked.Value;
        string recipientId = txtBxTo.Text;
        
        int recipientFoundInd = 0;
        if (privateFlag)
        {           
            var query = ParseObject.GetQuery(queryItemName).Limit(1000);
            IEnumerable<ParseObject> results = await query.FindAsync();
            string To = "";
            string From = "";
            

            foreach (ParseObject messages in results)
            {
                try
                {
                    From = messages.Get<string>("Id");
                    To = messages.Get<string>("To");
                    checkRecipient(From, To, recipientId, ref recipientFoundInd);          
                }
                catch (Exception ex)
                {
                    continue;
                }
            }
        }       
        if ((privateFlag && recipientFoundInd > 0) || !privateFlag)
        {

            ParseObject GPSParseObject = new ParseObject(queryItemName);
            GPSParseObject["MessageText"] = textMessage.Text;
            GPSParseObject["Id"] = txtBxMyId.Text;
            GPSParseObject["To"] = txtBxTo.Text;

            GPSParseObject["Private"] = privateFlag;

            await GPSParseObject.SaveAsync();
            string textHeader = MessageTextHeaders[privateFlag];
            listMessages.Items.Add("Me: " + textHeader + textMessage.Text);         

            listMessages.SelectedIndex = listMessages.Items.Count - 1;
            listMessages.ScrollIntoView(listMessages.SelectedItem);
            textMessage.Text = "";

            var query2 = ParseObject.GetQuery(queryItemName).Limit(1000);
            IEnumerable<ParseObject> results2 = await query2.FindAsync();

            foreach (ParseObject messages2 in results2)
            {
                lastObjectId = messages2.ObjectId;
            }
        }
        else
        {
            MessageBox.Show("Private message must have a To id that exists in the system", "Warning");
        }
    }

    private int checkRecipient(string From, string To, string recipientId, ref int recipientFound)
    {        
        if (From == recipientId || To == recipientId)
        {
            recipientFound++;           
        }
        return recipientFound;
    }
   

    private void btnSend_Click(object sender, RoutedEventArgs e)
    {
        //This method will validate the fact that all required fields are filled in and not just with spaces.  If they are filled in, call a method to send a message.  
        if (textMessage.Text != "" && textMessage.Text.Trim().Length != 0 && txtBxMyId.Text != "" && txtBxMyId.Text.Trim().Length != 0 && txtBxTo.Text != "" && txtBxTo.Text.Trim().Length != 0)
        {
            ParseObject GPSParseObject = new ParseObject(queryItemName);
            sendMessage();
        }
        else
        {
            //if here we know some data is missing so call the showErrorMessages method. 
            showErrorMessages();           
        }
    }    

    private void showErrorMessages()
    {
        string warningMessage = "";
        int a = textMessage.Text.Trim().Length;
        if (textMessage.Text == "" || textMessage.Text.Trim().Length == 0)
        {
            warningMessage += "Please enter some text to send\n";

        }
        if (txtBxMyId.Text == "" || txtBxMyId.Text.Trim().Length == 0)
        {
            warningMessage += "Please enter your id\n";
        }
        if (txtBxTo.Text == "" || txtBxTo.Text.Trim().Length == 0)
        {
            warningMessage += "Please enter a recipient id";
        }
        MessageBox.Show(warningMessage, "Warning");
    }

    private void btnLoadHistory_Click(object sender, RoutedEventArgs e)
    {
        if (txtBxMyId.Text == "")
        {
            MessageBox.Show("Please enter your id");
        }
        else
        {
            InitialMethod();
        }
    }
  }
}
