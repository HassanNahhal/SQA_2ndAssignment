﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Parse;
using System.Windows.Threading;


namespace WPFParseStarterProject {
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window {

    public string lastObjectId = "";
     
    public  MainWindow() {
      InitializeComponent();

      DispatcherTimer timer = new DispatcherTimer();
      timer.Interval = TimeSpan.FromSeconds(1);
      timer.Tick += timer_Tick;
      timer.Start();
     
      
      //InitialMethod();
    }

    private async void InitialMethod()
    {       

        ParseObject GPSParseObject2 = new ParseObject("GPSFromServer");
      
        var query = ParseObject.GetQuery("ChatMessages");
        IEnumerable<ParseObject> results = await query.FindAsync();

        foreach (ParseObject messages in results)
        {
            try
            {
                string MessageBody = messages.Get<string>("MessageText");
                string From = messages.Get<string>("Id");
                string To = messages.Get<string>("To");


                //bool privateOrPublic = messages.Get<Boolean>("Private");
                if ((messages.Get<Boolean>("Private") && To == txtBxMyId.Text) || (messages.Get<Boolean>("Private") == false) || (From == txtBxMyId.Text))
                {
                    if (From == txtBxMyId.Text)
                    {
                        if (messages.Get<Boolean>("Private"))
                        {
                            listMessages.Items.Add("Me [Private]: " + MessageBody);
                        }
                        else
                        {
                            listMessages.Items.Add("Me: " + MessageBody);
                        }
                    }
                    else
                    {
                        if (messages.Get<Boolean>("Private"))
                        {
                            listMessages.Items.Add(From + "[Private]: " + MessageBody);
                        }
                        else
                        {
                            listMessages.Items.Add(From + ": " + MessageBody);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                continue;
            }

            
            
            lastObjectId = messages.ObjectId;

        }

        listMessages.SelectedIndex = listMessages.Items.Count - 1;
        listMessages.ScrollIntoView(listMessages.SelectedItem);
      
    }

    async void timer_Tick(object sender, EventArgs e)
    {
        var query = ParseObject.GetQuery("ChatMessages");
        IEnumerable<ParseObject> results = await query.FindAsync();
        string MessageBody = "";
        string From = "";
        string To = "";
        string objectId = "";
        bool privateFlag = false;
        
        foreach (ParseObject messages in results)
        {
            try
            {

                MessageBody = messages.Get<string>("MessageText");
                From = messages.Get<string>("Id");
                objectId = messages.ObjectId;
                privateFlag = (messages.Get<Boolean>("Private"));
                To = messages.Get<string>("To");
               
            }
            catch (Exception ex)
            {
                continue;
            }
            
        }

        if (objectId != lastObjectId)
        {
            if ((privateFlag && To == txtBxMyId.Text) || (privateFlag == false) && To != "")
            {
                if (privateFlag)
                {
                    From += " [Private]";
                }
                listMessages.Items.Add(From + ": " + MessageBody);
                listMessages.SelectedIndex = listMessages.Items.Count - 1;
                listMessages.ScrollIntoView(listMessages.SelectedItem);
            }
        }

        lastObjectId = objectId;
    }
      

    private void txtBox1_TextChanged(object sender, TextChangedEventArgs e)
    {

    }

    private void btnConnect_Click(object sender, RoutedEventArgs e)
    {
       
    }

    private void MessageCallBack(IAsyncResult aResult)
    {
         
    }

    private async void btnSend_Click(object sender, RoutedEventArgs e)
    {

        ParseObject GPSParseObject = new ParseObject("ChatMessages");


        GPSParseObject["MessageText"] = textMessage.Text;
        GPSParseObject["Id"] = txtBxMyId.Text;
        GPSParseObject["To"] = txtBxTo.Text;
          
        bool flag = chckBxPrivate.IsChecked.Value;
        GPSParseObject["Private"] = flag;


        await GPSParseObject.SaveAsync();
        if (flag)
        {
            listMessages.Items.Add("Me: [Private] " + textMessage.Text);
        }
        else
        {
            listMessages.Items.Add("Me: " + textMessage.Text);
        }
        
        listMessages.SelectedIndex = listMessages.Items.Count -1;
        listMessages.ScrollIntoView(listMessages.SelectedItem);
        textMessage.Text = "";

        var query = ParseObject.GetQuery("ChatMessages");
        IEnumerable<ParseObject> results = await query.FindAsync();
        
        foreach (ParseObject messages in results)
        {           
           
            lastObjectId = messages.ObjectId;
        }

    }

    private void btnLoadHistory_Click(object sender, RoutedEventArgs e)
    {
        if (txtBxMyId.Text == "")
        {
            MessageBox.Show("Please enter your id");
        }
        else
        {
            InitialMethod();
        }
    }
  }
}
