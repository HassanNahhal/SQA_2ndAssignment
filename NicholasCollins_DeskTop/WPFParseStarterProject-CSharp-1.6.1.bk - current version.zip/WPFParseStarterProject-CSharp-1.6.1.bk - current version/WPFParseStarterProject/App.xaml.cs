﻿using Parse;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WPFParseStarterProject {
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application {
    public App() {
      this.Startup += this.Application_Startup;

      // Initialize the Parse client with your Application ID and .NET Key found on
      // your Parse dashboard
      //ParseClient.Initialize("YOUR APPLICATION ID", "YOUR .NET KEY");
      ParseClient.Initialize("WUXa2xvzApxSNu65oisCysyqWHahMjIVJ1o13TXq", "qi2N6r6EVxgTRHbXZhGBx0otPD1xcOMB4FrKl7y0");

     
      

     // GPSParseObject.put("GPSLocation", "(40.123,-80.123)");
     // GPSParseObject.saveInBackground();
    }

    private async void Application_Startup(object sender, StartupEventArgs args) {
      await ParseAnalytics.TrackAppOpenedAsync();
     /* ParseObject GPSParseObject = new ParseObject("GPSCoordinates");


      GPSParseObject["GPSLocation"] = "(42.123,-82.123)";
      await GPSParseObject.SaveAsync();

      ParseObject GPSParseObject2 = new ParseObject("GPSFromServer");
      var query = ParseObject.GetQuery("GPSCoordinates");
      IEnumerable<ParseObject> results = await query.FindAsync();*/

     
      
      int j = 0;
      j++;
       

    }
  }
}
